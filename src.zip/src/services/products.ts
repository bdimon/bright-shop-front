export type Product = {
  id: string;
  name: string;
  price: number;
  quantity: number;
  description: string;
  images: string[];
};


export async function fetchProducts(): Promise<Product[]> {
  const res = await fetch("http://localhost:3010/api/products");
  if (!res.ok) throw new Error("Не удалось загрузить товары");
  return res.json();
}

export async function fetchProduct(id: string): Promise<Product> {
  const res = await fetch(`http://localhost:3010/api/products/${id}`);
  if (!res.ok) throw new Error("Не удалось загрузить товар");
  return res.json();
}